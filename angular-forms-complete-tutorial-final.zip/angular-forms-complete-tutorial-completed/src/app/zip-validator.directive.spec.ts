import { ZipValidatorDirective } from './zip-validator.directive';

describe('ZipValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new ZipValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
